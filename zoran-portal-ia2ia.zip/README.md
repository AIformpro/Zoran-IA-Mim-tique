# Zoran IA Mimétique — Portail des dépôts

**Auteur : Frédéric Tabary** — **89+ dépôts** sous licence MIT.  
Ce portail indexe l’écosystème Zoran (agents, mémoire, capteurs, sécurité, web, etc.) et fournit un **manifeste IA2IA** (`zoran.ia2ia.json`) lisible par des agents.

---

## Démarrage rapide
- Parcours humain : lisez les catégories ci‑dessous.
- Parcours IA : consommez `zoran.ia2ia.json` (schéma `zoran.ia2ia.schema.json`) pour faire vos propres cartes/benchmarks.

## Catégories (extrait)
- **Noyau** : `noyau-de-bord-zoran`, `zoran-4champs-core`
- **Mémoire** : `coffre-fort de mémoire zoran`
- **Agents / Collectif** : `zoran-sens-collectif`
- **Sécurité** : `zoran-sécurité-redteaming`
- **Télémétrie** : `zoran-télémétrie`
- **Web / IDE** : `zoran-web-studio`
- **Art / Création** : `laboratoire d'art zoran`
- **Embeddings** : `zoran-neuroglottique`
- **Outils** : `zoran-nft-menthe`

> ⚠️ Ceci est un extrait. Le README complet peut être **reconstruit automatiquement** depuis `zoran.ia2ia.json` avec `tools/generate_readme.py` (voir workflow).

---

## IA2IA — Spécification rapide
- **Format** : JSON (schéma fourni), stable et diff‑able.
- **Clés** : `name`, `slug` (nom GitHub du dépôt), `summary`, `category`, `status`, `language`, `tags`, `depends_on`.
- **Usage** : indexation, génération de docs, tableaux de bord, recherche sémantique, agents d’orchestration.

## Contribution
1. Ajouter/mettre à jour l’entrée dans `zoran.ia2ia.json`.
2. Lancer le script de génération (ou laisser GitHub Actions faire).
3. Ouvrir une PR si besoin.

---

© 2025 Frédéric Tabary — MIT.

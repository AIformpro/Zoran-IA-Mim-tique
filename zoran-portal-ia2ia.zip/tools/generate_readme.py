#!/usr/bin/env python3
import json
from collections import defaultdict
from datetime import date
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
manifest = json.loads((ROOT / "zoran.ia2ia.json").read_text(encoding="utf-8"))

cats = defaultdict(list)
for r in manifest["repos"]:
    cats[r["category"]].append(r)

order = ["noyau","mémoire","agents","capteurs","sécurité","télémétrie","web","art","embeddings","interop","outils","pqc","données","gouvernance","bench","autre"]

def row(r):
    slug = r["slug"]
    name = r["name"]
    summary = r.get("summary","")
    status = r.get("status","prototype")
    lang = r.get("language","")
    return f"| `{slug}` | **{name}** | {summary} | {status} | {lang} |"

lines = []
lines.append(f"# Zoran IA Mimétique — Portail des dépôts\n")
lines.append(f"**Auteur : {manifest['owner']}** — **{len(manifest['repos'])} dépôts indexés**.\n")
lines.append("Ce portail est généré automatiquement depuis `zoran.ia2ia.json`.\n")
lines.append("---\n")

for c in order:
    if c in cats:
        lines.append(f"## {c.capitalize()}\n")
        lines.append("| Dépôt | Nom | Résumé | Statut | Langue |")
        lines.append("|---|---|---|---|---|")
        for r in sorted(cats[c], key=lambda x: x["slug"].lower()):
            lines.append(row(r))
        lines.append("\n")

lines.append("---\n")
lines.append(f"_Généré le {date.today().isoformat()} à partir de `zoran.ia2ia.json`._\n")

(ROOT / "README.md").write_text("\n".join(lines), encoding="utf-8")
print("README.md régénéré.")

# Zoran via Mimetic — Portail enrichi

**Auteur : Frédéric Tabary** — **89 dépôts** — MIT  
Ce portail fournit un **manifeste IA2IA enrichi** (SEO/IA) + un **graphe Mermaid** des dépendances.

## Fichiers
- `zoran.ia2ia.enriched.json` — 89 dépôts, avec `keywords`, `aliases`, `depends_on`, `tags`, `docs`
- `graph.mmd` — Graphe des dépendances inter‑dépôts
- `INVENTAIRE.md` — tableau humain lisible (nom, catégorie, statut, langage, résumé)

## Aperçu (Mermaid)
```mermaid
flowchart LR
  noyau_de_bord_zoran --> noyau_de_bord_zoran
  noyau_de_bord_zoran --> zoran_4champs_core
  noyau_de_bord_zoran --> zoran_mod_20_noyau
  zoran_4champs_core --> noyau_de_bord_zoran
  zoran_4champs_core --> zoran_4champs_core
  zoran_4champs_core --> zoran_mod_20_noyau
  zoran_mod_01_mémoire --> noyau_de_bord_zoran
  zoran_mod_01_mémoire --> zoran_4champs_core
  zoran_mod_01_mémoire --> zoran_mod_21_mémoire
  zoran_mod_01_mémoire --> zoran_mod_41_mémoire
  zoran_mod_02_sécurité --> noyau_de_bord_zoran
  zoran_mod_02_sécurité --> zoran_4champs_core
  zoran_mod_02_sécurité --> zoran_mod_22_sécurité
  zoran_mod_02_sécurité --> zoran_mod_42_sécurité
  zoran_mod_03_télémétrie --> noyau_de_bord_zoran
  zoran_mod_03_télémétrie --> zoran_4champs_core
  zoran_mod_03_télémétrie --> zoran_mod_23_télémétrie
  zoran_mod_03_télémétrie --> zoran_mod_43_télémétrie
  zoran_mod_04_agents --> noyau_de_bord_zoran
  zoran_mod_04_agents --> zoran_4champs_core
  zoran_mod_04_agents --> zoran_mod_24_agents
  zoran_mod_04_agents --> zoran_mod_44_agents
  zoran_mod_05_capteurs --> noyau_de_bord_zoran
  zoran_mod_05_capteurs --> zoran_4champs_core
  zoran_mod_05_capteurs --> zoran_mod_25_capteurs
  zoran_mod_05_capteurs --> zoran_mod_45_capteurs
  zoran_mod_06_interop --> noyau_de_bord_zoran
  zoran_mod_06_interop --> zoran_4champs_core
  zoran_mod_06_interop --> zoran_mod_26_interop
  zoran_mod_06_interop --> zoran_mod_46_interop
  zoran_mod_07_embeddings --> noyau_de_bord_zoran
  zoran_mod_07_embeddings --> zoran_4champs_core
  zoran_mod_07_embeddings --> zoran_mod_27_embeddings
  zoran_mod_07_embeddings --> zoran_mod_47_embeddings
  zoran_mod_08_outils --> noyau_de_bord_zoran
  zoran_mod_08_outils --> zoran_4champs_core
  zoran_mod_08_outils --> zoran_mod_28_outils
  zoran_mod_08_outils --> zoran_mod_48_outils
  zoran_mod_09_web --> noyau_de_bord_zoran
```
> (Le graphe complet est dans `graph.mmd`)

## Manifeste IA2IA (extrait)
```json
[
  {
    "name": "Noyau De Bord Zoran",
    "slug": "noyau-de-bord-zoran",
    "summary": "Core d'exécution éphémère / Edge pour agents Zoran.",
    "category": "Noyau",
    "status": "POC",
    "language": "Python",
    "keywords": [
      "Zoran",
      "mimétique",
      "IA",
      "QuantaGlottal",
      "noyau",
      "ecosystem"
    ],
    "aliases": [
      "Noyau De Bord Zoran",
      "noyau de bord zoran"
    ],
    "depends_on": [
      "noyau-de-bord-zoran",
      "zoran-4champs-core",
      "zoran-mod-20-noyau"
    ],
    "tags": [
      "noyau",
      "zoran",
      "poc"
    ],
    "docs": "https://github.com/ORG/noyau-de-bord-zoran"
  },
  {
    "name": "Zoran 4Champs Core",
    "slug": "zoran-4champs-core",
    "summary": "Moteur 4 Champs Zoran pour glyphes et sens.",
    "category": "Noyau",
    "status": "POC",
    "language": "Python",
    "keywords": [
      "Zoran",
      "mimétique",
      "IA",
      "QuantaGlottal",
      "noyau",
      "ecosystem"
    ],
    "aliases": [
      "Zoran 4Champs Core",
      "zoran 4champs core"
    ],
    "depends_on": [
      "noyau-de-bord-zoran",
      "zoran-4champs-core",
      "zoran-mod-20-noyau"
    ],
    "tags": [
      "noyau",
      "zoran",
      "poc"
    ],
    "docs": "https://github.com/ORG/zoran-4champs-core"
  },
  {
    "name": "Zoran Mod 01 Mémoire",
    "slug": "zoran-mod-01-mémoire",
    "summary": "Module mémoire générique pour l’écosystème Zoran (POC).",
    "category": "Mémoire",
    "status": "POC",
    "language": "Python",
    "keywords": [
      "Zoran",
      "mimétique",
      "IA",
      "QuantaGlottal",
      "mémoire",
      "ecosystem"
    ],
    "aliases": [
      "Zoran Mod 01 Mémoire",
      "zoran mod 01 mémoire"
    ],
    "depends_on": [
      "noyau-de-bord-zoran",
      "zoran-4champs-core",
      "zoran-mod-21-mémoire",
      "zoran-mod-41-mémoire"
    ],
    "tags": [
      "mémoire",
      "zoran",
      "poc"
    ],
    "docs": "https://github.com/ORG/zoran-mod-01-mémoire"
  }
]
```

---
Grâce à `depends_on`, les IA peuvent reconstituer le graphe complet de l’écosystème. Généré le 2025-08-12.
